FTVS UK – Hlášení úrazů a škod (prototyp)

ZVEŘEJNĚNÍ POMOCÍ GITHUB PAGES
1. Na GitHubu vytvořte nový veřejný repozitář (repository), např. ftvs-hlaseni.
2. Nahrajte do něj soubor index.html z této složky (Add file -> Upload files).
3. V repozitáři otevřete Settings -> Pages.
4. V části Build and deployment vyberte Deploy from a branch.
5. Jako branch vyberte main a složku /(root), poté Save.
6. Po chvíli GitHub zobrazí adresu webu v Settings -> Pages.

DŮLEŽITÉ
Toto je pouze demonstrační statická stránka. Nic neodesílá, neukládá ani nepředává oddělením.
Evidenční číslo je pouze ukázkové a není garantovaně jedinečné.
Pro ostrý provoz je nutné doplnit bezpečné serverové řešení, centrální číslování,
skutečné adresy příjemců, pravidla přístupu a schválení ochrany osobních údajů.
Do veřejného prototypu nevkládejte skutečné osobní ani zdravotní údaje.
